#!/usr/bin/env bash
# source this file to link to tasmanian libraries without additional flags
@Tasmanian_config_line1@
@Tasmanian_config_line2@
@Tasmanian_config_line3@
