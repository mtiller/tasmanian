#!/usr/bin/env bash
# source this file to execute tasgrid and tasdream after install
@Tasmanian_config_line1@
@Tasmanian_config_line2@
